package com.example.simpleplayer;

public interface SeekBarTextCallback {
	public void setCurrentTime(String time);
	public void setTotalTime(String time);
}
